package com.epam.vaccinemanagementsystem.view;

import static com.epam.vaccinemanagementsystem.constant.Constants.Login.*;


import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.vaccinemanagementsystem.controller.LoginController;
import com.epam.vaccinemanagementsystem.model.User;

@Component
public class LoginView {

	@Autowired
	private LoginController loginController;
	
	@Autowired
	private ApplicationView appView;
	
	
	public void launchApplication() {
		Scanner inputReader = new Scanner(System.in);
		//logger.info("Covid Vaccination Portal\n========================");
		//logger.info("1.Login\n2.Close\n\nPlease Enter your choice:");
		int choice = inputReader.nextInt();
		switch (choice) {
		case LOGIN:
			login();
			break;
		case CLOSEAPP:
			//logger.info("\n!---Closed The Application---!");
			break;
		default:
			//logger.info("Not a Valid Option");
		}
		inputReader.close();
	}
	
	void login() {
		Scanner readInput = new Scanner(System.in);
		System.out.print("\nEnter your registered aadharNumber:");
		String aadharCardNumber = readInput.next();
		User user = loginController.isRegisteredUser(aadharCardNumber);
		if(user==null)
			System.out.println();
			//logger.info("\n!---Invalid Aadhar Card Number--!");
		else
			applicationView(user);
		readInput.close();
	}
	void applicationView(User user) {
	  // logger.info("\nLogged In Successfully:"+user.getUserName());
	   appView.readUserInputView();
	}
	

}
