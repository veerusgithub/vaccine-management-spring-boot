package com.epam.vaccinemanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.epam.vaccinemanagementsystem.model.User;
import com.epam.vaccinemanagementsystem.model.Vaccine;

@Repository
public class Dao {

	private List<User> listOfUsers;
	private Vaccine vaccine;

	

	public List<User> fetchUsers() {
		return listOfUsers;
	}

	public void saveUser(User newUser) {
		listOfUsers.add(newUser);
	}

	public void updateExistingUser(User updatedUser) {
		for (User user : listOfUsers) {
		   if(user.getAadharCardNumber().equalsIgnoreCase(updatedUser.getAadharCardNumber())) {
			   user.setVaccineShotCount(updatedUser.getVaccineShotCount());
			   user.setShotTwoVaccinatedDate(updatedUser.getShotTwoVaccinatedDate());
		   }
		}
	}
	
	public long fetchExistingVaccineCount() {
		return vaccine.getVaccineCount();
	}

	public boolean updateExistingVaccineStock(long newVaccineStockCount) {
		vaccine.setVaccineCount(fetchExistingVaccineCount()+newVaccineStockCount);
		return true;
	}
}