package com.epam.vaccinemanagementsystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vaccines")
public class Vaccine {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer vaccineId;
	
	@Column
	private String vaccineName;
	
	@Column
	private long vaccineCount;
	
	public Vaccine() {
	}

	public Vaccine(String vaccineName, int vaccineCount) {
		this.vaccineName = vaccineName;
		this.vaccineCount = vaccineCount;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	public long getVaccineCount() {
		return vaccineCount;
	}

	public void setVaccineCount(long vaccineCount) {
		this.vaccineCount = vaccineCount;
	}

} 