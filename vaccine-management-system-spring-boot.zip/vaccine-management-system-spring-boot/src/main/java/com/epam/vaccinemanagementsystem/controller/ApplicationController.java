package com.epam.vaccinemanagementsystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.epam.vaccinemanagementsystem.dao.Dao;
import com.epam.vaccinemanagementsystem.dao.UserDao;
import com.epam.vaccinemanagementsystem.dao.VaccineDao;
import com.epam.vaccinemanagementsystem.model.User;
import com.epam.vaccinemanagementsystem.model.Vaccine;

@Controller
public class ApplicationController {

	@Autowired
	private UserDao dao;

	@Autowired
	private VaccineDao vaccineDao;
	

	public List<User> getListOfUsers() {
		return dao.findAll();
	}

	public void addNewUser(User user) {
		dao.save(user);
	}
	
	public void updateUserState(User user) {
		
		dao.save(user);
	}

	
	public long getAvaliableVaccineStock() {
		List<Vaccine> list  = vaccineDao.findAll();
		Long totalVaccineCount =list.stream().mapToLong(Vaccine::getVaccineCount).sum();
		return totalVaccineCount;
	}

	public boolean updateVaccineStock(long newVaccineStockCount, String vaccineName) {
		 Optional<Vaccine> optional = vaccineDao.findByVaccineName(vaccineName);
		 if(optional.isPresent()) {
			Vaccine vaccine = optional.get();
			vaccine.setVaccineCount(newVaccineStockCount);
			vaccineDao.save(vaccine);
			return true;
		 }
		return false;
	}

}