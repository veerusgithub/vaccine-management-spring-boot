package com.epam.vaccinemanagementsystem.view;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.vaccinemanagementsystem.controller.ApplicationController;
import com.epam.vaccinemanagementsystem.model.User;
import static com.epam.vaccinemanagementsystem.constant.Constants.Application.ADD_NEW_USER;
import static com.epam.vaccinemanagementsystem.constant.Constants.Application.CLOSEAPP;
import static com.epam.vaccinemanagementsystem.constant.Constants.Application.DISPLAY_VACCINE_STOCK;
import static com.epam.vaccinemanagementsystem.constant.Constants.Application.REGISTERED_USERS;
import static com.epam.vaccinemanagementsystem.constant.Constants.Application.UPDATE_VACCINE_STOCK;

@Component
public class ApplicationView {

	//static Logger logger = LogManager.getLogger(ApplicationView.class);
	@Autowired
	private ApplicationController appController;


	public void readUserInputView() {
		while (true) {
		//	logger.info("\nApplication View\n================");
			//logger.info("\nPlease Enter Your Choice:");
			System.out.print(
					"\n1.List of Vaccinated Users\n2.Check & Vaccine User\n3.Display Vaccine Stock\n4.Update Vaccine Stock\n5.Close");
			System.out.print("\nPlease Enter Your Choice:");
			Scanner readUserInput = new Scanner(System.in);
			int choice = readUserInput.nextInt();
			switch (choice) {
			case REGISTERED_USERS:
				List<User> listOfUsers = appController.getListOfUsers();
				//logger.info("\nList Of Vaccinated Users\n========================");
				if (listOfUsers.size() >= 1)
					System.out.println();
				//	listOfUsers.forEach((user) -> logger.info(user));
				else
					//logger.info("!---Still no one vaccinated Yet---!");
				break;
			case ADD_NEW_USER:
				System.out.print("\nPlease enter AadharCardNumber:");
				String aadharCardNumber = readUserInput.next();
				if (checkUserVaccineStatus(aadharCardNumber)) {
					User user = new User();
					System.out.print("Please enter your userName:");
					String userName = readUserInput.next();
					System.out.print("Please enter age:");
					int age = readUserInput.nextInt();
					user.setAadharCardNumber(aadharCardNumber);
					user.setUserName(userName);
					user.setAge(age);
					user.setUserVaccinated(true);
					user.setShotOneVaccinatedDate(LocalDateTime.now().toString());
					int count = user.getVaccineShotCount();
					user.setVaccineShotCount(count + 1);
					appController.addNewUser(user);
					//logger.info("\nUser Vaccinated his first Dose Successfully ");
					}
				break;
			case DISPLAY_VACCINE_STOCK:
				//logger.info("\nAvaliable Vaccine Count:" + appController.getAvaliableVaccineStock());
				break;
			case UPDATE_VACCINE_STOCK:
				System.out.print("\nEnter New Vaccine Count:");
				long newVaccineStockCount = readUserInput.nextLong();
				boolean status = appController.updateVaccineStock(newVaccineStockCount,"COVAXIN");
				if (status)
					//logger.info("\n Vaccine count has been Updated Successfully");
				break;
			case CLOSEAPP:
				//logger.info("\n!---------------Application Closed--------------!");
				readUserInput.close();
				System.exit(0);
				break;
			default:
				//logger.info("\nInvalid Option");
			}
		}

	}

	public boolean checkUserVaccineStatus(String aadharCardNumber) {
		List<User> listOfUsers = appController.getListOfUsers();
		if (listOfUsers.size() >= 0) {
			for (User user : listOfUsers) {
				if (user.getAadharCardNumber().equalsIgnoreCase(aadharCardNumber)) {
					if (user.getVaccineShotCount() == 1)
						{
						  //logger.info("\nThis Person has already vaccinated Dose 1 at this date and time:"+user.getShotOneVaccinatedDate());
						  user.setShotTwoVaccinatedDate(LocalDateTime.now().toString());
						  user.setVaccineShotCount(2);
						  appController.updateUserState(user);
						}
					else if (user.getVaccineShotCount() == 2)
					//	logger.info("\nThis Person has Done with his 2 shots of vaccination");
					return false;
				}
			}
		}
		return true;
	}

}
