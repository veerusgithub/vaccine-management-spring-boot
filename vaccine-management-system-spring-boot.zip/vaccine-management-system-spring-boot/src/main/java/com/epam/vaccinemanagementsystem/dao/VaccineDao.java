package com.epam.vaccinemanagementsystem.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.epam.vaccinemanagementsystem.model.Vaccine;

public interface VaccineDao extends JpaRepository<Vaccine, Integer> {

	Optional<Vaccine> findByVaccineName(String vaccineName);

}
