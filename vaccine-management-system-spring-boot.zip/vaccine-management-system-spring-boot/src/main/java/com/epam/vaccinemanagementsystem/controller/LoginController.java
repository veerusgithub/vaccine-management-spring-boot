package com.epam.vaccinemanagementsystem.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.epam.vaccinemanagementsystem.dao.UserDao;
import com.epam.vaccinemanagementsystem.model.User;

@Controller
public class LoginController {

	@Autowired
	private UserDao userDao;


	public User isRegisteredUser(String aadharCardNumber) {
		Optional<User> optional=userDao.findByAadharCardNumber(aadharCardNumber);
		if (optional.isPresent())
			return optional.get();
		else
			return null;
	}

}
