package com.epam.vaccinemanagementsystem;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.epam.vaccinemanagementsystem.dao.UserDao;
import com.epam.vaccinemanagementsystem.model.User;
import com.epam.vaccinemanagementsystem.view.LoginView;

@SpringBootApplication
public class VaccineManagementSystemApplication {
	
	public static void main(String[] args) {
		ApplicationContext applicationContext=   SpringApplication.run(VaccineManagementSystemApplication.class, args);
		LoginView loginView = applicationContext.getBean(LoginView.class);
		loginView.launchApplication();
		
	}
	
	
	
	 @Bean
	    CommandLineRunner init(UserDao userRepository) {
	        return args -> {
	        	Optional<User> optional = userRepository.findByAadharCardNumber("987654321987");
				if(!optional.isPresent()) {
					User  loginUser = new User();
					loginUser.setUserName("Rahul");
					loginUser.setUserRole("User");
					loginUser.setAge(23);
					loginUser.setAadharCardNumber("987654321987");
					User user =userRepository.save(loginUser);
	        };
	    };
	 }

	
}
