### Relevant Articles:

- [Spring Boot With JavaServer Pages (JSP)](https://www.baeldung.com/spring-boot-jsp)
