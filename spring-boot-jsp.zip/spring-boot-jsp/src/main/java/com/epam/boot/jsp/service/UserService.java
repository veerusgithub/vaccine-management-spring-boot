package com.epam.boot.jsp.service;

import com.epam.boot.jsp.dto.UserDto;
import com.epam.boot.jsp.dto.VaccineDto;

import java.util.Collection;

public interface UserService {
    Collection<UserDto> getUsers();
    public UserDto addUser(UserDto userDto);
    Collection<VaccineDto> getVaccines();
    public VaccineDto addVaccine(VaccineDto vaccineDto);
}
