package com.epam.boot.jsp.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class LibraryControllerAdvice {

    @ExceptionHandler(value = DuplicateUserException.class)
    public ModelAndView duplicateUserException(DuplicateUserException e) {
        final ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }

    @ExceptionHandler(value = DuplicateVaccineException.class)
    public ModelAndView duplicateVaccineException(DuplicateVaccineException e) {
        final ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }
}