package com.epam.boot.jsp.repository.impl;

import com.epam.boot.jsp.repository.VaccineRepository;
import com.epam.boot.jsp.repository.model.Vaccine;

import java.util.*;

public class InMemoryVaccineRepository implements VaccineRepository {

    private final Map<String, Vaccine> storedVaccine;

    public InMemoryVaccineRepository(Map<String, Vaccine> storedVaccine) {
        this.storedVaccine = new HashMap<>();
        this.storedVaccine.putAll(storedVaccine);
    }

    @Override
    public Collection<Vaccine> findAll() {
        if (storedVaccine.isEmpty()) {
            return Collections.emptyList();
        }

        return storedVaccine.values();
    }

    @Override
    public Optional<Vaccine> findById(String vaccineName) {
        return Optional.ofNullable(storedVaccine.get(vaccineName));
    }

    @Override
    public Vaccine add(Vaccine vaccine) {
        storedVaccine.put(vaccine.getVaccineName(), vaccine);
        return vaccine;
    }
}
