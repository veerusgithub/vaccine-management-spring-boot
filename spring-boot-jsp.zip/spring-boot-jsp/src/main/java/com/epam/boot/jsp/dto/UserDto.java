package com.epam.boot.jsp.dto;

public class UserDto {

    private String userName;
    private String aadharCardNumber;
    private int age;
    private String userRole;
    private boolean isUserVaccinated;
    private int vaccineShotCount;
    private String shotOneVaccinatedDate;
    private String shotTwoVaccinatedDate;

    public UserDto() {
    }

    public UserDto(String userName, String aadharCardNumber, int age, String userRole,
                   boolean isUserVaccinated,
                   int vaccineShotCount, String shotOneVaccinatedDate, String shotTwoVaccinatedDate
                   ) {
        this.userName = userName;
        this.aadharCardNumber = aadharCardNumber;
        this.age = age;
        this.userRole= userRole;
        this.isUserVaccinated=isUserVaccinated;
        this.vaccineShotCount=vaccineShotCount;
        this.shotOneVaccinatedDate=shotOneVaccinatedDate;
        this.shotTwoVaccinatedDate= shotTwoVaccinatedDate;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAadharCardNumber() {
        return aadharCardNumber;
    }

    public void setAadharCardNumber(String aadharCardNumber) {
        this.aadharCardNumber = aadharCardNumber;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public boolean isUserVaccinated() {
        return isUserVaccinated;
    }

    public void setUserVaccinated(boolean userVaccinated) {
        isUserVaccinated = userVaccinated;
    }

    public int getVaccineShotCount() {
        return vaccineShotCount;
    }

    public void setVaccineShotCount(int vaccineShotCount) {
        this.vaccineShotCount = vaccineShotCount;
    }

    public String getShotOneVaccinatedDate() {
        return shotOneVaccinatedDate;
    }

    public void setShotOneVaccinatedDate(String shotOneVaccinatedDate) {
        this.shotOneVaccinatedDate = shotOneVaccinatedDate;
    }

    public String getShotTwoVaccinatedDate() {
        return shotTwoVaccinatedDate;
    }

    public void setShotTwoVaccinatedDate(String shotTwoVaccinatedDate) {
        this.shotTwoVaccinatedDate = shotTwoVaccinatedDate;
    }
}
