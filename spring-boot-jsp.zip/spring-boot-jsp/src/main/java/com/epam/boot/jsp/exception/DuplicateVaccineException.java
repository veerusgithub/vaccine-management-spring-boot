package com.epam.boot.jsp.exception;

import com.epam.boot.jsp.dto.VaccineDto;
import lombok.Getter;

@Getter
public class DuplicateVaccineException extends RuntimeException {
    private final VaccineDto vaccineDto;

    public DuplicateVaccineException(VaccineDto vaccineDto) {
        this.vaccineDto = vaccineDto;
    }
}