package com.epam.boot.jsp.controller;

import com.epam.boot.jsp.dto.LoginDto;
import com.epam.boot.jsp.repository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("/login")
public class LoginController {

    private final UserRepository userRepository;

    public LoginController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    public String getLoginPage(Model model){
        model.addAttribute("login", new LoginDto());
        return "login";
    }

    @PostMapping("/user")
    public RedirectView login(@ModelAttribute("login") LoginDto loginDto, RedirectAttributes redirectAttributes) {


        if(userRepository.findById(loginDto.getUserName()).isPresent() && "password".equals(loginDto.getPassword())){
            final RedirectView redirectView = new RedirectView("/user/viewUsers", true);
            return  redirectView;
        }
        final RedirectView redirectView = new RedirectView("/login", true);
        redirectAttributes.addFlashAttribute("loginFailure", true);
        return redirectView;
    }
}
