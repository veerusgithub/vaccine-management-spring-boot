package com.epam.boot.jsp.repository;

import com.epam.boot.jsp.repository.model.Vaccine;

import java.util.Collection;
import java.util.Optional;

public interface VaccineRepository {
    Collection<Vaccine> findAll();

    Optional<Vaccine> findById(String vaccineName);

    Vaccine add(Vaccine vaccine);

}
