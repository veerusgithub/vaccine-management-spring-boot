package com.epam.boot.jsp.service.impl;

import com.epam.boot.jsp.dto.UserDto;
import com.epam.boot.jsp.dto.VaccineDto;
import com.epam.boot.jsp.exception.DuplicateUserException;
import com.epam.boot.jsp.exception.DuplicateVaccineException;
import com.epam.boot.jsp.repository.UserRepository;
import com.epam.boot.jsp.repository.VaccineRepository;
import com.epam.boot.jsp.repository.model.User;
import com.epam.boot.jsp.repository.model.Vaccine;
import com.epam.boot.jsp.service.UserService;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private  final VaccineRepository vaccineRepository;

    public UserServiceImpl(UserRepository userRepository, VaccineRepository vaccineRepository) {
        this.userRepository = userRepository;
        this.vaccineRepository = vaccineRepository;
    }

    @Override
    public Collection<UserDto> getUsers() {
        return userRepository.findAll()
            .stream()
            .map(UserServiceImpl::convertUser)
            .collect(Collectors.toList());
    }

    @Override
    public UserDto addUser(UserDto userDto) {
        final Optional<User> existingUser = userRepository.findById(userDto.getAadharCardNumber());
        if (existingUser.isPresent()) {
            throw new DuplicateUserException(userDto);
        }

        final User savedUser = userRepository.add(convertUserDto(userDto));
        return convertUser(savedUser);
    }
    @Override
    public VaccineDto addVaccine(VaccineDto vaccineDto) {
        final Optional<Vaccine> existingVaccine = vaccineRepository.findById(vaccineDto.getVaccineName());
        if (existingVaccine.isPresent()) {
            throw new DuplicateVaccineException(vaccineDto);
        }

        final Vaccine savedVaccine = vaccineRepository.add(convertVaccineDto(vaccineDto));
        return convertVaccine(savedVaccine);
    }

    private Vaccine convertVaccineDto(VaccineDto vaccineDto) {
        return  new Vaccine(vaccineDto.getVaccineName(),vaccineDto.getVaccineCount());
    }

    @Override
    public Collection<VaccineDto> getVaccines() {
        return vaccineRepository.findAll()
                .stream()
                .map(UserServiceImpl::convertVaccine)
                .collect(Collectors.toList());
    }
    private static VaccineDto convertVaccine(Vaccine vaccine) {
        return new VaccineDto(vaccine.getVaccineName(), vaccine.getVaccineCount());
    }

    private static UserDto convertUser(User user) {
        return new UserDto(user.getUserName(), user.getAadharCardNumber(), user.getAge(),
                user.getUserRole(),user.isUserVaccinated(),user.getVaccineShotCount(), user.getShotOneVaccinatedDate(),
                user.getShotTwoVaccinatedDate());
    }

    private static User convertUserDto(UserDto user) {
        return new User(user.getUserName(), user.getAadharCardNumber(), user.getAge(),
                user.getUserRole(),user.isUserVaccinated(),user.getVaccineShotCount(), user.getShotOneVaccinatedDate(),
                user.getShotTwoVaccinatedDate());
    }
}
