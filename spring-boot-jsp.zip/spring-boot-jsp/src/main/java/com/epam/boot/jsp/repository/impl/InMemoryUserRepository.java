package com.epam.boot.jsp.repository.impl;

import com.epam.boot.jsp.repository.UserRepository;
import com.epam.boot.jsp.repository.model.User;

import java.util.*;

public class InMemoryUserRepository implements UserRepository {

    private final Map<String, User> storedUsers;

    public InMemoryUserRepository(Map<String, User> storedUsers) {
        this.storedUsers = new HashMap<>();
        this.storedUsers.putAll(storedUsers);
    }

    @Override
    public Collection<User> findAll() {
        if (storedUsers.isEmpty()) {
            return Collections.emptyList();
        }

        return storedUsers.values();
    }

    @Override
    public Optional<User> findById(String aadharCardNo) {
        return Optional.ofNullable(storedUsers.get(aadharCardNo));
    }

    @Override
    public User add(User user) {
        storedUsers.put(user.getAadharCardNumber(), user);
        return user;
    }
}
