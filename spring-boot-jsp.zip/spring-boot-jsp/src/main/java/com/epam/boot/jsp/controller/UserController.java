package com.epam.boot.jsp.controller;

import com.epam.boot.jsp.dto.UserDto;
import com.epam.boot.jsp.dto.VaccineDto;
import com.epam.boot.jsp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("/user")
public class UserController {

    private  final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/viewUsers")
    public String getAllUsers(Model model){

        model.addAttribute("users",userService.getUsers());
        return "view-users";
    }

    @GetMapping("/getUserPage")
    public String addUser(Model model){
        model.addAttribute("user", new UserDto());
        return "add-user";
    }

    @PostMapping("/addUser")
    public RedirectView addBook(@ModelAttribute("user") UserDto userDto, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/getUserPage", true);
        UserDto savedUser = userService.addUser(userDto);
        redirectAttributes.addFlashAttribute("savedUser", savedUser);
        redirectAttributes.addFlashAttribute("addUserSuccess", true);
        return redirectView;
    }

    @GetMapping("/getVaccinePage")
    public String getVaccinePage(Model model){
        model.addAttribute("vaccine", new VaccineDto());
        return "add-vaccine";
    }

    @GetMapping("viewVaccine")
    public String getAvaliableVaccineStock(Model model) {
        model.addAttribute("vaccines",userService.getVaccines());
        return "view-vaccines";
    }

    @PostMapping("/addVaccine")
    public RedirectView updateVaccineStock(@ModelAttribute("vaccine") VaccineDto vaccineDto,
                                      RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/getVaccinePage", true);
        VaccineDto savedVaccine = userService.addVaccine(vaccineDto);
        redirectAttributes.addFlashAttribute("savedVaccine", savedVaccine);
        redirectAttributes.addFlashAttribute("addVaccineSuccess", true);
        return redirectView;
    }

}
