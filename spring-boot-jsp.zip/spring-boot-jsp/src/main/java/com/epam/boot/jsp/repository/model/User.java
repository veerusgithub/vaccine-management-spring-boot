package com.epam.boot.jsp.repository.model;


public class User {
	
	/*@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_id")*/
//	private Integer userId;

	//@Column(name="user_role")
	private String userRole;
	
//	@Column(name="user_name")
	private String userName;
	
//	@Column(name="aadhar_card_number")
	private String aadharCardNumber;
	
//	@Column(name="age")
	private int age;
	
//	@Column(name="is_user_vaccinated")
	private boolean isUserVaccinated;
	
//	@Column(name="vaccine_shot_count")
	private int vaccineShotCount;
	
//	@Column(name="shot_one_vaccinated_date")
	private String shotOneVaccinatedDate;
	
//	@Column(name="shot_two_vaccinated_date")
	private String shotTwoVaccinatedDate;

	public User() {
		this.isUserVaccinated = false;
		this.userRole = "user";
		this.vaccineShotCount = 0;
		this.shotOneVaccinatedDate = "Not Yet";
		this.shotTwoVaccinatedDate = "Not Yet";
	}

	public User(String userName, String aadharCardNumber, int age, String userRole,
				boolean isUserVaccinated,
				int vaccineShotCount, String shotOneVaccinatedDate, String shotTwoVaccinatedDate) {
		this.userName = userName;
		this.aadharCardNumber = aadharCardNumber;
		this.age = age;
		this.userRole= userRole;
		this.isUserVaccinated=isUserVaccinated;
		this.vaccineShotCount=vaccineShotCount;
		this.shotOneVaccinatedDate=shotOneVaccinatedDate;
		this.shotTwoVaccinatedDate= shotTwoVaccinatedDate;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAadharCardNumber() {
		return aadharCardNumber;
	}

	public void setAadharCardNumber(String aadharCardNumber) {
		this.aadharCardNumber = aadharCardNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isUserVaccinated() {
		return isUserVaccinated;
	}

	public void setUserVaccinated(boolean isUserVaccinated) {
		this.isUserVaccinated = isUserVaccinated;
	}

	public int getVaccineShotCount() {
		return vaccineShotCount;
	}

	public void setVaccineShotCount(int vaccineShotCount) {
		this.vaccineShotCount = vaccineShotCount;
	}

	public String getShotOneVaccinatedDate() {
		return shotOneVaccinatedDate;
	}

	public void setShotOneVaccinatedDate(String shotOneVaccinatedDate) {
		this.shotOneVaccinatedDate = shotOneVaccinatedDate;
	}

	public String getShotTwoVaccinatedDate() {
		return shotTwoVaccinatedDate;
	}

	public void setShotTwoVaccinatedDate(String shotTwoVaccinatedDate) {
		this.shotTwoVaccinatedDate = shotTwoVaccinatedDate;
	}

	@Override
	public String toString() {
		return "User [userName=" + userName + ", aadharCardNumber=" + aadharCardNumber + ", age=" + age
				+ ", isUserVaccinated=" + isUserVaccinated + ", vaccineShotCount=" + vaccineShotCount + "]";
	}


}