package com.epam.boot.jsp;

import java.util.HashMap;
import java.util.Map;

import com.epam.boot.jsp.repository.UserRepository;
import com.epam.boot.jsp.repository.VaccineRepository;
import com.epam.boot.jsp.repository.impl.InMemoryUserRepository;
import com.epam.boot.jsp.repository.impl.InMemoryVaccineRepository;
import com.epam.boot.jsp.repository.model.User;
import com.epam.boot.jsp.repository.model.Vaccine;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class SpringBootJspConfiguration {


    @Bean
    public UserRepository provideUserRepository(){
        return  new InMemoryUserRepository(initialUserData());
    }

    @Bean
    public VaccineRepository provideVaccineRepository(){
        return new InMemoryVaccineRepository(initialVaccineData());
    }

    private Map<String, Vaccine> initialVaccineData() {
        Map<String, Vaccine> initialData= new HashMap<>();
        initialData.put("vaccine-1", new Vaccine("Vaccine-1",12));
        initialData.put("vaccine-2", new Vaccine("Vaccine-2",1002));
        return initialData;
    }

    private Map<String, User> initialUserData() {
        Map<String, User> initialData= new HashMap<>();
        initialData.put("123456789012",new User("user-1","123456789012",22,"user",false,1,"12-05-2021",""));
        initialData.put("123456789013",new User("user-2","123456789012",52,"user",false,1,"12-05-2021",""));
        initialData.put("123456789014",new User("user-3","123456789012",42,"user",false,1,"12-05-2021",""));
        return initialData;
    }


}