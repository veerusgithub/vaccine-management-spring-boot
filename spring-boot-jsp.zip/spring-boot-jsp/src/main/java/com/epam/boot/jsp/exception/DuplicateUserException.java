package com.epam.boot.jsp.exception;

import com.epam.boot.jsp.dto.UserDto;
import lombok.Getter;

@Getter
public class DuplicateUserException extends RuntimeException {
    private final UserDto userDto;

    public DuplicateUserException(UserDto userDto) {
        this.userDto = userDto;
    }
}