package com.epam.boot.jsp.repository;

import com.epam.boot.jsp.repository.model.User;

import java.util.Collection;
import java.util.Optional;


public interface UserRepository {
    Collection<User> findAll();

    Optional<User> findById(String aadharCardNo);

    User add(User user);
}
